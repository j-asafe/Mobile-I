import React, { useState } from 'react'; // Importa o React e o hook useState para gerenciar estados
import { View, TextInput, Button } from 'react-native'; // Importa componentes básicos do React Native
import { styles } from './CSS/style'; // Importa os estilos de um arquivo externo

const App = () => { // Define o componente funcional App
  // Declara três variáveis de estado: numero1, numero2 e resultado
  const [numero1, setNumero1] = useState (""); // Estado para o primeiro número (inicializado com uma string vazia)
  const [numero2, setNumero2] = useState (""); // Estado para o segundo número (inicializado com uma string vazia)
  const [resultado, setResultado] = useState (""); // Estado para armazenar o resultado da soma (inicializado com uma string vazia)

  // Função que realiza a soma dos dois números
  const calculadoraSomar = () => {
    const num1 = parseFloat(numero1); // Converte o valor de numero1 de string para número de ponto flutuante
    const num2 = parseFloat(numero2); // Converte o valor de numero2 de string para número de ponto flutuante

    // Verifica se os dois valores são números válidos
    if (!isNaN(num1) && !isNaN(num2)){
      setResultado ((num1 + num2).toString()); // Se os valores forem válidos, soma e converte o resultado para string
    }
    else{
      setResultado('Entrada Inválida'); // Se algum dos valores não for um número, exibe uma mensagem de erro
    }
  };

  return(
    <View style={styles.container}> {/* Renderiza o container principal com estilo */}
      <TextInput 
        style={styles.input} // Aplica o estilo do campo de input
        placeholder="Digite um número" // Texto que aparece quando o campo está vazio
        keyboardType="numeric" // Exibe o teclado numérico para a entrada
        valued={numero1} // Atribui o valor atual de numero1 ao campo de entrada
        onChangeText={setNumero1} // Atualiza o estado de numero1 conforme o usuário digita
      />
      <TextInput 
        style={styles.input} // Aplica o estilo do campo de input
        placeholder="Digite um número" // Texto que aparece quando o campo está vazio
        keyboardType="numeric" // Exibe o teclado numérico para a entrada
        valued={numero2} // Atribui o valor atual de numero2 ao campo de entrada
        onChangeText={setNumero2} // Atualiza o estado de numero2 conforme o usuário digita
      />
      <TextInput 
        style={styles.input} // Aplica o estilo do campo de input
        placeholder="Resultado" // Texto que aparece quando o campo está vazio
        value={resultado} // Atribui o valor atual de resultado ao campo de entrada
        onChangeText={setResultado} // Impede a alteração direta do resultado (apenas leitura)
        editable={false} // Torna o campo não editável, já que é apenas para exibir o resultado
      />
      <Button title="calcular" onPress={calculadoraSomar} /> {/* Botão que chama a função calculadoraSomar quando pressionado */}
    </View>
  );
};

export default App; // Exporta o componente App para ser utilizado em outros lugares
