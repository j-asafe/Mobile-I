
                                    //JOÃO ASAFE SOARES - 2°DS//

import React, { useState } from 'react';
import { View, TextInput, Button, Text } from 'react-native';
import { styles } from './css/styles';

const App = () => {
  const [nota1, setNota1] = useState('');
  const [nota2, setNota2] = useState('');
  const [nota3, setNota3] = useState('');
  const [nota4, setNota4] = useState('');
  const [resultado, setResultado] = useState('');
  const [media, setMedia] = useState('');

const checarNotas = () => {
  const formatNota1 = parseFloat(nota1);
  const formatNota2 = parseFloat(nota2);
  const formatNota3 = parseFloat(nota3);
  const formatNota4 = parseFloat(nota4);

  if (!isNaN(formatNota1) && !isNaN(formatNota2) && !isNaN(formatNota3) && !isNaN(formatNota4)) {
    const calculoMedia = ((formatNota1 + formatNota2 + formatNota3 + formatNota4) / 4);
    setMedia(calculoMedia.toFixed(2));

    if (calculoMedia >= 6) {
      setResultado("Aprovado!");
    } else if (calculoMedia >= 4 && calculoMedia < 6) {
      setResultado("Recuperação!");
    } else {
      setResultado("Reprovado!");
    }
  } else {
    setResultado('O número inserido é inválido!');
    setMedia("");
  }
};

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Digite a 1° nota"
        keyboardType="numeric"
        value={nota1}
        onChangeText={setNota1}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite a 2° nota"
        keyboardType="numeric"
        value={nota2}
        onChangeText={setNota2}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite a 3° nota"
        keyboardType="numeric"
        value={nota3}
        onChangeText={setNota3}
      />

      <TextInput
        style={styles.input}
        placeholder="Digite a 4° nota"
        keyboardType="numeric"
        value={nota4}
        onChangeText={setNota4}
      />
        
      <Text style={styles.resultado}>
        Sua média é:
      </Text>
      
      <TextInput
      style={styles.input}
      value={media}
      editable={false}
      />

      <Button title="Clique para ver sua média" onPress={checarNotas} />
      
      <Text style={styles.resultado}>
        {resultado}
      </Text>

    </View>
  );
};

export default App;
