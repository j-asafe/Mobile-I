                                    //JOÃO ASAFE SOARES - 2°DS//

import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';
import { styles } from './css/styles';

const App = () => {
  const [idade, setIdade] = useState('');
  const [verificar, setVerificar] = useState('');

  const checarIdade = () => {
    const formatIdade = parseInt(idade, 10);
 
    if (!isNaN(formatIdade)) {
      setVerificar(formatIdade >= 18 ? 'Você é maior de idade' : 'Você é menor de idade');
    } 
    else {
      setVerificar('O número inserido é inválido!');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Digite sua idade"
        keyboardType="numeric"
        value={idade}
        onChangeText={setIdade}
      />

      <TextInput
        style={styles.input}
        value={verificar}
        editable={false}
      />

      <Button title="Verificar" onPress={checarIdade} />
    </View>
  );
};

export default App;
