import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text } from 'react-native';
import { styles } from './CSS/style';

const App = () => {
  const [numero1, setNumero1] = useState("");
  const [numero2, setNumero2] = useState("");
  const [resultado, setResultado] = useState("");

  const calculadoraSomar = () => {
    const num1 = parseFloat(numero1);
    const num2 = parseFloat(numero2);
    if (!isNaN(num1) && !isNaN(num2)) {
      setResultado((num1 + num2).toString());
    } else {
      setResultado('Entrada Inválida');
    }
  };

  const calculadoraSubtrair = () => {
    const num1 = parseFloat(numero1);
    const num2 = parseFloat(numero2);
    if (!isNaN(num1) && !isNaN(num2)) {
      setResultado((num1 - num2).toString());
    } else {
      setResultado('Entrada Inválida');
    }
  };

  const calculadoraMultiplicar = () => {
    const num1 = parseFloat(numero1);
    const num2 = parseFloat(numero2);
    if (!isNaN(num1) && !isNaN(num2)) {
      setResultado((num1 * num2).toString());
    } else {
      setResultado('Entrada Inválida');
    }
  };

  const calculadoraDividir = () => {
    const num1 = parseFloat(numero1);
    const num2 = parseFloat(numero2);
    if (!isNaN(num1) && !isNaN(num2)) {
      setResultado(num2 !== 0 ? (num1 / num2).toString() : 'Erro: Divisão por zero');
    } else {
      setResultado('Entrada Inválida');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput 
        style={styles.input} 
        placeholder="Digite um número"
        keyboardType="numeric"
        value={numero1}
        onChangeText={setNumero1}
      />
      <TextInput 
        style={styles.input} 
        placeholder="Digite um número"
        keyboardType="numeric"
        value={numero2}
        onChangeText={setNumero2}
      />
      <View style={styles.containerBotao}>
        <TouchableOpacity style={styles.botao} onPress={calculadoraSomar}>
          <Text style={styles.textoBotao}>+</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.botao} onPress={calculadoraSubtrair}>
          <Text style={styles.textoBotao}>-</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.botao} onPress={calculadoraMultiplicar}>
          <Text style={styles.textoBotao}>x</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.botao} onPress={calculadoraDividir}>
          <Text style={styles.textoBotao}>/</Text>
        </TouchableOpacity>
      </View>
      
      <TextInput 
        style={styles.inputResultado} 
        placeholder="Resultado"
        value={resultado}
        editable={false}
      />
    </View>
  );
};

export default App;
