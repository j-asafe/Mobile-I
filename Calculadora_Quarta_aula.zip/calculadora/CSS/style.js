import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  input: {
    width: '80%',
    height: 50,
    borderColor: '#007bff',
    borderWidth: 2,
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 10,
    fontSize: 18,
    backgroundColor: '#fff',
  },
  containerBotao: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
    width: '80%',
  },
  botao: {
    backgroundColor: '#007bff',
    width: 50, 
    height: 50, 
    borderRadius: 10, 
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 10, 
  },
  textoBotao: {
    color: '#fff',
    fontSize: 30,
    fontWeight: 'bold',
  },
  inputResultado: {
    width: '80%',
    height: 50,
    borderColor: 'gray',
    borderWidth: 2,
    borderRadius: 10,
    marginTop: 20,
    paddingHorizontal: 10,
    fontSize: 18,
    backgroundColor: '#fff',
    textAlign: 'center',
  },
});
